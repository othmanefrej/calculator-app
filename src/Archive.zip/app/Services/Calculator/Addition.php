<?php

namespace App\Services\Calculator;

class Addition implements OperationInterface
{
    public function calculate(float $a, float $b): float
    {
        return $a + $b;
    }

    public function validate(float $a, float $b): array
    {
        return [
            "error" => false,
            "message" => ""
        ];
    }
}
