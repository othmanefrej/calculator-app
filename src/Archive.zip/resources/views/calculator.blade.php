<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculator</title>
</head>

<body>
    <h1>Calculator</h1>
    @if(session('error'))
    <div class="error">
        <strong>Error : </strong>{{ session('error') }}
    </div>
    @endif

    <form action="/calculator" method="POST">
        @csrf
        <input type="number" name="number1" value="{{ old('number1', $number1 ?? '') }}" required>
        <select name="operation" required>
            <option value="add" {{ (old('operation', $operation ?? '') == 'add') ? 'selected' : '' }}>+</option>
            <option value="subtract" {{ (old('operation', $operation ?? '') == 'subtract') ? 'selected' : '' }}>-</option>
            <option value="multiply" {{ (old('operation', $operation ?? '') == 'multiply') ? 'selected' : '' }}>*</option>
            <option value="divide" {{ (old('operation', $operation ?? '') == 'divide') ? 'selected' : '' }}>/</option>
        </select>
        <input type="number" name="number2" value="{{ old('number2', $number2 ?? '') }}" required>
        <button type="submit">Calculate</button>
    </form>
    <br>
    @if(session('result'))
    <strong>Result: </strong>{{ session('result') }}
    @endif

    @if($errors->any())
    <div>
        <ul>
            @foreach($errors->all() as $error)
            <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif
</body>

</html>