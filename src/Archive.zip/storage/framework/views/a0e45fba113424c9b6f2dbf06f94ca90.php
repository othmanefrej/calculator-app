<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculator</title>
</head>

<body>
    <h1>Calculator</h1>
    <?php if(session('error')): ?>
    <div class="error">
        <strong>Error : </strong><?php echo e(session('error')); ?>

    </div>
    <?php endif; ?>

    <form action="/calculator" method="POST">
        <?php echo csrf_field(); ?>
        <input type="number" name="number1" value="<?php echo e(old('number1', $number1 ?? '')); ?>" required>
        <select name="operation" required>
            <option value="add" <?php echo e((old('operation', $operation ?? '') == 'add') ? 'selected' : ''); ?>>+</option>
            <option value="subtract" <?php echo e((old('operation', $operation ?? '') == 'subtract') ? 'selected' : ''); ?>>-</option>
            <option value="multiply" <?php echo e((old('operation', $operation ?? '') == 'multiply') ? 'selected' : ''); ?>>*</option>
            <option value="divide" <?php echo e((old('operation', $operation ?? '') == 'divide') ? 'selected' : ''); ?>>/</option>
        </select>
        <input type="number" name="number2" value="<?php echo e(old('number2', $number2 ?? '')); ?>" required>
        <button type="submit">Calculate</button>
    </form>
    <br>
    <?php if(session('result')): ?>
    <strong>Result: </strong><?php echo e(session('result')); ?>

    <?php endif; ?>

    <?php if($errors->any()): ?>
    <div>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
</body>

</html><?php /**PATH /Users/macbookpro/Desktop/Projects/test-php-INVENTIV/calculator-app/resources/views/calculator.blade.php ENDPATH**/ ?>