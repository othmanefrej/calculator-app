<?php

namespace App\Services\Calculator;

class CalculatorService
{
    protected $operation;


    public function __construct(OperationInterface $operation)
    {
        $this->operation = $operation;
    }

    public function validate(float $a, float $b): array
    {
        return $this->operation->validate($a, $b);
    }

    public function execute(float $a, float $b): float
    {
        return $this->operation->calculate($a, $b);
    }
}
